// 인디고 브리핑: 고정 좌측 내비게이션과 넓은 브리핑 캔버스로 로그인 후 경험을 랜딩과 연결한다.
import { BarChart3, ChevronRight, FileText, Home, LogOut, PiggyBank, Search, Settings, Sparkles, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { BrandMark } from "./BrandMark";
import { SiteHeader } from "./SiteHeader";

const navItems = [
  { href: "/dashboard", label: "한눈에 보기", icon: Home },
  { href: "/policies", label: "정책 매칭", icon: Search, count: "12" },
  { href: "/reports", label: "AI 분석 리포트", icon: Sparkles, count: "3" },
  { href: "/savings", label: "저축플랜", icon: PiggyBank },
];

export function DashboardLayout({ children, title, eyebrow, action }: { children: React.ReactNode; title: string; eyebrow: string; action?: React.ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const toggle = () => setOpen((value) => !value);
    window.addEventListener("toggle-sidebar", toggle);
    return () => window.removeEventListener("toggle-sidebar", toggle);
  }, []);
  return (
    <div className="app-shell min-h-screen bg-[#f7f9fc] text-ink">
      <aside className={`app-sidebar fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col border-r border-[#e5ebf5] bg-white px-5 py-6 transition-transform duration-200 lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="mb-10 flex items-center justify-between px-2"><Link href="/dashboard" onClick={() => setOpen(false)}><BrandMark size="sm" /></Link><button className="rounded-lg p-1 text-slate-400 lg:hidden" onClick={() => setOpen(false)} aria-label="사이드바 닫기"><X size={18} /></button></div>
        <div className="mb-3 px-3 text-[10px] font-extrabold uppercase tracking-[0.18em] text-slate-400">My briefing</div>
        <nav className="grid gap-1" aria-label="서비스 내비게이션">
          {navItems.map(({ href, label, icon: Icon, count }) => {
            const active = location === href;
            return <Link key={href} href={href} onClick={() => setOpen(false)} className={`group flex items-center justify-between rounded-xl px-3 py-3 text-[13px] font-bold transition ${active ? "bg-[#eef3ff] text-[#2457d6]" : "text-slate-500 hover:bg-slate-50 hover:text-ink"}`}><span className="flex items-center gap-3"><Icon size={17} strokeWidth={active ? 2.2 : 1.8} /><span>{label}</span></span>{count && <span className={`rounded-full px-2 py-0.5 text-[10px] ${active ? "bg-[#2457d6] text-white" : "bg-slate-100 text-slate-400"}`}>{count}</span>}</Link>;
          })}
        </nav>
        <div className="my-7 h-px bg-slate-100" />
        <div className="mb-3 px-3 text-[10px] font-extrabold uppercase tracking-[0.18em] text-slate-400">Support</div>
        <nav className="grid gap-1"><button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-bold text-slate-500 transition hover:bg-slate-50 hover:text-ink" onClick={() => alert("프로필 설정은 곧 연결됩니다.")}><Settings size={17} strokeWidth={1.8} />프로필 설정</button><button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-bold text-slate-500 transition hover:bg-slate-50 hover:text-ink" onClick={() => alert("고객센터는 평일 09:00–18:00 운영됩니다.")}><FileText size={17} strokeWidth={1.8} />이용 안내</button></nav>
        <div className="mt-auto rounded-2xl bg-[#f5f8fd] p-4"><div className="mb-3 flex h-8 w-8 items-center justify-center rounded-[10px] bg-[#e2edff] text-[#2457d6]"><BarChart3 size={16} /></div><p className="text-[12px] font-extrabold leading-5 text-ink">내 정책 적합도<br /><span className="text-[#2457d6]">상위 14%</span>로 분석됐어요.</p><Link href="/reports" className="mt-3 flex items-center justify-between text-[11px] font-bold text-slate-500 hover:text-[#2457d6]">분석 자세히 보기 <ChevronRight size={13} /></Link></div>
        <button className="mt-5 flex items-center gap-3 px-3 text-[12px] font-bold text-slate-400 hover:text-slate-600" onClick={() => window.location.href = "/"}><LogOut size={16} strokeWidth={1.8} />로그아웃</button>
      </aside>
      {open && <button className="fixed inset-0 z-30 bg-ink/20 lg:hidden" onClick={() => setOpen(false)} aria-label="메뉴 닫기" />}
      <div className="lg:pl-[248px]"><SiteHeader app /><main className="mx-auto max-w-[1440px] px-4 pb-16 pt-8 sm:px-8 lg:px-12 lg:pt-10"><div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#2457d6]">{eyebrow}</div><h1 className="text-[30px] font-extrabold tracking-[-0.055em] text-ink sm:text-[38px]">{title}</h1></div>{action}</div>{children}</main></div>
    </div>
  );
}

export function SectionLabel({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) { return <div className="mb-4 flex items-center justify-between"><h2 className="text-[15px] font-extrabold tracking-[-0.03em] text-ink">{children}</h2>{action}</div>; }
