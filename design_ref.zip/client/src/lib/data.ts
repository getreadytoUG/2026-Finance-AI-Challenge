// 인디고 브리핑: 정책 신호, 예상 혜택, 저축 ledger를 같은 어휘로 공유한다.
import type { LucideIcon } from "lucide-react";
import { BriefcaseBusiness, Building2, GraduationCap, HeartPulse, House, PiggyBank, Sparkles, WalletCards } from "lucide-react";

export type Policy = {
  id: string;
  title: string;
  organization: string;
  category: string;
  tags: string[];
  deadline: string;
  status: "신청 가능" | "마감 임박" | "관심 등록";
  fit: number;
  benefit: string;
  description: string;
  icon: LucideIcon;
  tone: "blue" | "mint" | "violet" | "orange";
};

export const categories = [
  { label: "일자리", detail: "취업·창업", icon: BriefcaseBusiness, color: "blue" },
  { label: "주거", detail: "전월세·대출", icon: House, color: "sky" },
  { label: "교육", detail: "학자금·훈련", icon: GraduationCap, color: "violet" },
  { label: "금융·복지", detail: "생활 안정", icon: HeartPulse, color: "mint" },
];

export const policies: Policy[] = [
  {
    id: "youth-rent",
    title: "청년월세 한시 특별지원",
    organization: "국토교통부 · 서울특별시",
    category: "주거",
    tags: ["월세", "주거", "청년"],
    deadline: "2026. 12. 31",
    status: "신청 가능",
    fit: 96,
    benefit: "월 최대 20만원",
    description: "독립 거주 청년의 월세 부담을 덜어주는 현금성 지원 정책이에요.",
    icon: House,
    tone: "blue",
  },
  {
    id: "newlywed-loan",
    title: "신혼부부 전용 전세자금",
    organization: "주택도시기금",
    category: "주거",
    tags: ["신혼부부", "전세", "대출"],
    deadline: "예산 소진 시",
    status: "신청 가능",
    fit: 91,
    benefit: "최대 3억원 대출",
    description: "결혼 7년 이내 부부를 위한 낮은 금리의 전세자금 대출입니다.",
    icon: Building2,
    tone: "mint",
  },
  {
    id: "employment",
    title: "청년도전 지원사업",
    organization: "고용노동부",
    category: "일자리",
    tags: ["취업", "수당", "상담"],
    deadline: "2026. 09. 18",
    status: "마감 임박",
    fit: 84,
    benefit: "최대 350만원",
    description: "구직을 포기하지 않도록 맞춤 상담과 참여수당을 지원합니다.",
    icon: BriefcaseBusiness,
    tone: "orange",
  },
  {
    id: "birth-bonus",
    title: "첫만남이용권",
    organization: "보건복지부",
    category: "금융·복지",
    tags: ["출산", "바우처", "복지"],
    deadline: "출생일로부터 1년",
    status: "신청 가능",
    fit: 79,
    benefit: "첫째 200만원",
    description: "출생 아동 양육에 필요한 초기 비용을 국민행복카드로 지원합니다.",
    icon: HeartPulse,
    tone: "violet",
  },
];

export const savingsPlan = {
  goal: 30000000,
  current: 18400000,
  monthly: 720000,
  expectedBenefit: 2400000,
  deadline: "2028. 06",
};

export const profile = {
  name: "민지님",
  age: "만 29세",
  region: "서울 마포구",
  household: "신혼부부",
  income: "연 4,800만원",
};

export const featureCards = [
  { title: "금융 정책 추천", detail: "내 조건에 맞는 정책만 모아봐요.", icon: WalletCards, path: "/policies", tone: "blue" },
  { title: "정책 읽기", detail: "필요한 정책을 빠르게 찾아요.", icon: BriefcaseBusiness, path: "/policies", tone: "sky" },
  { title: "AI로 정책 알기", detail: "혜택과 유의사항을 한 번에 확인해요.", icon: Sparkles, path: "/reports", tone: "violet" },
  { title: "저축플랜", detail: "목표까지 필요한 금액을 계산해요.", icon: PiggyBank, path: "/savings", tone: "mint" },
];
